# Run Conduktor Platform locally

### Usage

Run Conduktor Platform :    
Replace `<your-license>` with the license provided
```sh
./run-local.sh "<your-license>"
```

Stop Conduktor Platform
```sh
./stop-local.sh
```

If you want to delete all Conduktor Platform data
```sh
./rm-local.sh
```
### URL
Conduktor Platform is available on [http://localhost:8080](http://localhost:8080)

## Platform Url
[http://localhost:8080/home/](http://localhost:8080/home/)

### Credentials 
use the credential provided to the `./run-local`

## Requirements
