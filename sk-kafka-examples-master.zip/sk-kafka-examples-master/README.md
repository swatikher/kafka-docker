# sk-kafka-examples
DevTeams Documentation
PAY https://confluence.dcsg.com/display/PTP/Local+Development

examples with kafka
1. CICD Pipeline example with PCF Cloud Foundry
2. Docker Container - simple kafka example
3. Lenses Container - Kafka Dashboard, create topics, produce messages, consumers, connectors, REST, Schema Registry
4. Conduktor - Local Kafka Cluster Example Dashboard, create topics, produce messages, consumers
5. Confluent Control Center docker - Local Cluster, Create Topics, Produce messages, consumers
6. Apache Camel Kafka Springboot - local cluster, consumer, maven springboot project
